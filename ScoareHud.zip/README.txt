Thanks for downloading ScoreHub

To install:
1. Download Skript from here (https://github.com/SkriptLang/Skript/releases)

2. Then restart your server

3. Move the file "ScoreHub.sk" to the file located in "/plugins/skript/scripts" in your minecraft server file

Done!

See more on the github repository (https://github.com/Andrei12333/ScoreHud)

Editing can be done by editing the ScoreHud.sk file's options